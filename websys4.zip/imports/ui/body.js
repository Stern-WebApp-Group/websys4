import { Template } from 'meteor/templating';
import { Ilnesses, Remedy, Products } from '../api/illnesses.js';
import './body.html';


//onload function
Template.body.rendered = function() {
    //initialize autocomplete search input
    Meteor.typeahead.inject();
    Session.set('currentproduct', 1);
};


//list of helper functions that body.js will call.
Template.body.helpers({

    //return list of all remedies to the client
    remedies() {
        return Remedy.find({});
    },

    products() {
        console.log( Session.get('currentproduct'));
        return Products.find({"Remedy_ID": Session.get('currentproduct') });
    },

    //return list of illnesses to the autocomplete search
    illnessSearch: function() {
        return Ilnesses.find().fetch().map(function(object){ return {id: object.Remedy_ID, value: object.name}; });
    },

    // filtered out remedies based on search (hide all other remedies
    selected: function(event, suggestion, datasetName) {

        //split remedies returned by illness into array
        var query_ids = suggestion.id.split(',');

        //hide all rememdies
       $(".panel").hide();

        //show only filtered remedies
        for (var i = 0; i < query_ids.length; i++) {
            $("#"+ query_ids[i]).show();
        }//for

    },
});


Template.body.events({
    'click .remedy_button'(event) {
        // Prevent default browser form submit
        event.preventDefault();
        const target = event.target;
        Session.set('currentproduct', target.id);

    },
});