import { Mongo } from 'meteor/mongo';

//load Ilnessess collection
export const Ilnesses = new Mongo.Collection('illness');

//load Remedy collection
export const Remedy = new Mongo.Collection('remedy');

//load Remedy collection
export const Products = new Mongo.Collection('products');